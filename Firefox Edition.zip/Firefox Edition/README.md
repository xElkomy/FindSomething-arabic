
<img src="icons/365764486_123125147525866_6875513157502364595_n.png" dir="rtl" align="center">

<p dir="rtl" align="right">السلام عليكم ورحمة الله وبركاتة </p>

<p dir="rtl" align="right">
اضافة للمتصفح للمساعدة في ايجاد او الوصول الي بعض المسارات المهمة او المعلومات المهمة من خلال الصفحة وملفات الجافا سكربت والاداة تعمل بشكل سلبي بمعني انها لا ترسل اي طلبات للموقع جديدة.
</p>

## <h2 dir="rtl" align="right"> هدفنا</h2>
<p dir="rtl" align="right">هدفنا هو محاولة تعريب المحتوي الاجنبي </p>

<p dir="rtl" align="right">
حسابي علي موقع اكس او تويتر:
https://twitter.com/0xElkomy
</p>

## <h2 dir="rtl" align="right"> التثبيت</h2>

<p dir="rtl" align="right">
بص انت هتفتح المتصفح بتاعك الي هو في الحالة دي <p dir="rtl" align="right">firefox</p>
وبعد كدا هتلاقي في الاعدادت فوق 
Tools ثم Add-ons
![Debug-addons](image.png)
هتضغط علي 
Debug Add-ons
![load](image-1.png)
هتضغط علي 
Load Temporary Add-on…
ثم تختار ملف الي اسمه
mainfest.json
وبس كدا لاضافة اشتغلت
تحياتي
</p>


## <h2 dir="rtl" align="right"> شكرا</h2>
@momosecurity
